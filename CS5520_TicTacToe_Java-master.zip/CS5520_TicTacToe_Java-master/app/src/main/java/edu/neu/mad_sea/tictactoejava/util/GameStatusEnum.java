package edu.neu.mad_sea.tictactoejava.util;

public enum GameStatusEnum {
    FINISHED,
    IN_PROGRESS,
    START

}
