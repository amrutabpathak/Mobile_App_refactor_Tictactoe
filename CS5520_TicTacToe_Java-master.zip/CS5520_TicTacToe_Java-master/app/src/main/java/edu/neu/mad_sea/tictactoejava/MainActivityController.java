package edu.neu.mad_sea.tictactoejava;

import androidx.appcompat.app.AppCompatActivity;

import android.graphics.Color;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import edu.neu.mad_sea.tictactoejava.bean.Game;
import edu.neu.mad_sea.tictactoejava.bean.Player;
import edu.neu.mad_sea.tictactoejava.model.TGameModel;
import edu.neu.mad_sea.tictactoejava.util.Constants;
import edu.neu.mad_sea.tictactoejava.util.GameStatusEnum;

/**
 * This Android in Java application is meant to represent
 * the game tic-tac-toe. Game play details can be found at
 * https://en.wikipedia.org/wiki/Tic-tac-toe
 */

public class MainActivityController extends AppCompatActivity implements View.OnClickListener{

    /**
     * UI Components:
     *    - playerOneScore: number of games won by player one
     *    - playerTwoScore: number of games won by player two
     *    - playerStatus: displays the current overall game leader
     *    - buttons: nine game piece buttons
     *    - resetGame: button used to reset the entire game, player scores, and playerStatus
     */
    private static final String TAG = "MainActivityController";
    private TextView playerOneScore, playerTwoScore, playerStatus;
    private TGameModel model;

    private Button[] buttons = new Button[Constants.NUMBER_OF_CELLS];
    private Button resetGame;

    private Game game;

    /**
     * activePlayer: toggles between player one and two
     *    - true: player one's turn
     *    - false: player two's turn
     */
    private boolean isPlayerOneTurn;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // set and find IDs for TextViews and reset button
        playerOneScore = (TextView) findViewById(R.id.playerOneScore);
        playerTwoScore = (TextView) findViewById(R.id.playerTwoScore);
        playerStatus = (TextView) findViewById(R.id.playerStatus);
        resetGame = (Button) findViewById(R.id.resetGame);
        Log.d(TAG, "onCreate: Buttons created");
        game = new Game(GameStatusEnum.START, 0, "","", "", new Player(Constants.PLAYER_ONE_ID,0), new Player(Constants.PLAYER_TWO_ID,0), true);
        model = new TGameModel(game);

        // sets and finds all of the IDs for the game piece buttons.
        for (int i=0; i < buttons.length; i++) {
            String buttonID = "btn_" + i;
            Log.d(TAG, "onCreate: button"+buttonID);
            int resourceID = getResources().getIdentifier(buttonID, "id", getPackageName());
            buttons[i] = (Button) findViewById(resourceID);
            buttons[i].setOnClickListener(this);
        }





    }

    @Override
    public void onClick(View v) {
        // Checks to see if a button has been previously been pressed.
        // If button has been pressed, players cannot reselect a button, but if not, the button
        // is still selectable in game play.
        Log.d(TAG, "onClick: in here"+((Button) v).getText().toString());
        if(model.isAlreadySelected(((Button) v).getText().toString())){
            return;
        }

        // Below finds the button ID that was clicked and updates the game state.
        String buttonID = v.getResources().getResourceEntryName((v.getId()));
        game.setCellId(buttonID);
        Log.d(TAG, "onClick: clicked"+buttonID);

        game.setStatus(GameStatusEnum.IN_PROGRESS);
        setButtonFeatures(game, v);
        game = model.statusCheck();
        if(game.getStatus().equals(GameStatusEnum.FINISHED)){
            Toast.makeText(this, game.getMessage(), Toast.LENGTH_SHORT).show();
            playAgain();
            for (int i=0; i < buttons.length; i++) {
                int resourceID = getResources().getIdentifier("btn_"+i, "id", getPackageName());
                buttons[i] = (Button) findViewById(resourceID);
                buttons[i].setEnabled(false);
            }

        }
        updateText();
        // Reset game
        resetGame.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                playAgain();
                playerStatus.setText(Constants.NEW_GAME_MESSAGE);
            }
        });
    }

    private void updateText(){
        playerStatus.setText(game.getPlayerStatus());
        Log.d(TAG, "updateText: "+game.getPlayerOne().getScore());
        playerOneScore.setText(Integer.toString(game.getPlayerOne().getScore()));
        playerTwoScore.setText(Integer.toString(game.getPlayerTwo().getScore()));
    }


    private void setButtonFeatures(Game  game, View v){
        // Player markings depending on turn.
        if(game.isFirstPlayer()) {
            ((Button)v).setText(Constants.X);
            //((Button)v).setTextColor(Color.parseColor(String.valueOf(R.color.playerOneColor)));
        }
        else{
            ((Button)v).setText(Constants.O);
           // ((Button)v).setTextColor(Color.parseColor(String.valueOf(R.color.playerTwoColor)));
        }
    }




    // Starts a new round with a clean game board.
    public void playAgain() {
        game = model.resetBoard();

        for (int i = 0; i < buttons.length; i++) {
            int resourceID = getResources().getIdentifier("btn_"+i, "id", getPackageName());
            buttons[i] = (Button) findViewById(resourceID);
            buttons[i].setEnabled(true);
            buttons[i].setText("");

        }
        updateText();
    }

}